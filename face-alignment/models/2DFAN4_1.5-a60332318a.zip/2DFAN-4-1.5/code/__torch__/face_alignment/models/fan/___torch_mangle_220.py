class HourGlass(Module):
  __parameters__ = []
  training : bool
  b1_4 : __torch__.face_alignment.models.fan.___torch_mangle_135.ConvBlock
  b2_4 : __torch__.face_alignment.models.fan.___torch_mangle_142.ConvBlock
  b1_3 : __torch__.face_alignment.models.fan.___torch_mangle_149.ConvBlock
  b2_3 : __torch__.face_alignment.models.fan.___torch_mangle_156.ConvBlock
  b1_2 : __torch__.face_alignment.models.fan.___torch_mangle_163.ConvBlock
  b2_2 : __torch__.face_alignment.models.fan.___torch_mangle_170.ConvBlock
  b1_1 : __torch__.face_alignment.models.fan.___torch_mangle_177.ConvBlock
  b2_1 : __torch__.face_alignment.models.fan.___torch_mangle_184.ConvBlock
  b2_plus_1 : __torch__.face_alignment.models.fan.___torch_mangle_191.ConvBlock
  b3_1 : __torch__.face_alignment.models.fan.___torch_mangle_198.ConvBlock
  b3_2 : __torch__.face_alignment.models.fan.___torch_mangle_205.ConvBlock
  b3_3 : __torch__.face_alignment.models.fan.___torch_mangle_212.ConvBlock
  b3_4 : __torch__.face_alignment.models.fan.___torch_mangle_219.ConvBlock
  def forward(self: __torch__.face_alignment.models.fan.___torch_mangle_220.HourGlass,
    input: Tensor) -> Tensor:
    _0 = self.b3_4
    _1 = self.b3_3
    _2 = self.b3_2
    _3 = self.b3_1
    _4 = self.b2_plus_1
    _5 = self.b2_1
    _6 = self.b1_1
    _7 = self.b2_2
    _8 = self.b1_2
    _9 = self.b2_3
    _10 = self.b1_3
    _11 = self.b2_4
    _12 = (self.b1_4).forward(input, )
    input0 = torch.avg_pool2d(input, [2, 2], [2, 2], [0, 0], False, True, None)
    _13 = (_11).forward(input0, )
    _14 = (_10).forward(_13, )
    input1 = torch.avg_pool2d(_13, [2, 2], [2, 2], [0, 0], False, True, None)
    _15 = (_9).forward(input1, )
    _16 = (_8).forward(_15, )
    input2 = torch.avg_pool2d(_15, [2, 2], [2, 2], [0, 0], False, True, None)
    _17 = (_7).forward(input2, )
    _18 = (_6).forward(_17, )
    input3 = torch.avg_pool2d(_17, [2, 2], [2, 2], [0, 0], False, True, None)
    _19 = (_4).forward((_5).forward(input3, ), )
    _20 = (_3).forward(_19, )
    _21 = ops.prim.NumToTensor(torch.size(_20, 2))
    _22 = torch.to(CONSTANTS.c0, torch.device("cpu"), 6, False, False, None)
    _23 = torch.to(_21, 6, False, False, None)
    _24 = torch.to(torch.mul(_23, torch.detach(_22)), 6, False, False, None)
    _25 = ops.prim.NumToTensor(torch.size(_20, 3))
    _26 = torch.to(CONSTANTS.c0, torch.device("cpu"), 6, False, False, None)
    _27 = torch.to(_25, 6, False, False, None)
    _28 = torch.to(torch.mul(_27, torch.detach(_26)), 6, False, False, None)
    _29 = [int(torch.floor(_24)), int(torch.floor(_28))]
    up2 = torch.upsample_nearest2d(_20, _29, None, None)
    input4 = torch.add(_18, up2, alpha=1)
    _30 = (_2).forward(input4, )
    _31 = ops.prim.NumToTensor(torch.size(_30, 2))
    _32 = torch.to(CONSTANTS.c0, torch.device("cpu"), 6, False, False, None)
    _33 = torch.to(_31, 6, False, False, None)
    _34 = torch.to(torch.mul(_33, torch.detach(_32)), 6, False, False, None)
    _35 = ops.prim.NumToTensor(torch.size(_30, 3))
    _36 = torch.to(CONSTANTS.c0, torch.device("cpu"), 6, False, False, None)
    _37 = torch.to(_35, 6, False, False, None)
    _38 = torch.to(torch.mul(_37, torch.detach(_36)), 6, False, False, None)
    _39 = [int(torch.floor(_34)), int(torch.floor(_38))]
    up20 = torch.upsample_nearest2d(_30, _39, None, None)
    input5 = torch.add(_16, up20, alpha=1)
    _40 = (_1).forward(input5, )
    _41 = ops.prim.NumToTensor(torch.size(_40, 2))
    _42 = torch.to(CONSTANTS.c0, torch.device("cpu"), 6, False, False, None)
    _43 = torch.to(_41, 6, False, False, None)
    _44 = torch.to(torch.mul(_43, torch.detach(_42)), 6, False, False, None)
    _45 = ops.prim.NumToTensor(torch.size(_40, 3))
    _46 = torch.to(CONSTANTS.c0, torch.device("cpu"), 6, False, False, None)
    _47 = torch.to(_45, 6, False, False, None)
    _48 = torch.to(torch.mul(_47, torch.detach(_46)), 6, False, False, None)
    _49 = [int(torch.floor(_44)), int(torch.floor(_48))]
    up21 = torch.upsample_nearest2d(_40, _49, None, None)
    input6 = torch.add(_14, up21, alpha=1)
    _50 = (_0).forward(input6, )
    _51 = ops.prim.NumToTensor(torch.size(_50, 2))
    _52 = torch.to(CONSTANTS.c0, torch.device("cpu"), 6, False, False, None)
    _53 = torch.to(_51, 6, False, False, None)
    _54 = torch.to(torch.mul(_53, torch.detach(_52)), 6, False, False, None)
    _55 = ops.prim.NumToTensor(torch.size(_50, 3))
    _56 = torch.to(CONSTANTS.c0, torch.device("cpu"), 6, False, False, None)
    _57 = torch.to(_55, 6, False, False, None)
    _58 = torch.to(torch.mul(_57, torch.detach(_56)), 6, False, False, None)
    _59 = [int(torch.floor(_54)), int(torch.floor(_58))]
    up22 = torch.upsample_nearest2d(_50, _59, None, None)
    return torch.add(_12, up22, alpha=1)
